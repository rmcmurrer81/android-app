from __future__ import annotations

import argparse, json, mimetypes, secrets, socket, threading, time, urllib.parse, webbrowser
from http import cookies
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

from sarah.config import CONFIG
from sarah.database import connect, execute, init_db, now_iso, row, rows, log_event
from sarah.exporter import export_local_data
from sarah.image_tools import read_photo_bytes, sanitize_base64
from sarah.memory import list_memories, relevant_memories, save_memory
from sarah.prompting import system_prompt
from sarah.providers import ProviderError, get_provider
from sarah.security import verify_pin
from sarah.travel_tools import attraction_links, flight_deal_links, lodging_links

SESSIONS: dict[str,float]={}
SESSION_TTL=12*60*60


def get_history():
    data=rows("SELECT role,content FROM conversation_messages ORDER BY id DESC LIMIT ?",(CONFIG.max_history,)); data.reverse(); return [{"role":x["role"],"content":x["content"]} for x in data]

def context_for(text,live_search=False,vision=False):
    return {"memories":relevant_memories(text,CONFIG.max_memories),"trips":rows("SELECT * FROM trips ORDER BY CASE status WHEN 'planned' THEN 0 WHEN 'wishlist' THEN 1 ELSE 2 END,id DESC LIMIT 15"),"preferences":rows("SELECT * FROM preferences ORDER BY category,key LIMIT 50"),"facts":rows("SELECT tf.* FROM trip_facts tf JOIN trips t ON t.id=tf.trip_id ORDER BY tf.id DESC LIMIT 40"),"live_search":live_search,"vision":vision}

def local_ip():
    try:
        s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM); s.connect(("8.8.8.8",80)); v=s.getsockname()[0]; s.close(); return v
    except OSError:return "127.0.0.1"

class Handler(BaseHTTPRequestHandler):
    server_version="SarahLocal/0.1"
    def log_message(self,format,*args): print(f"[{self.log_date_time_string()}] {format%args}")
    def send_bytes(self,data:bytes,content_type="application/octet-stream",status=200,headers=None):
        self.send_response(status); self.send_header("Content-Type",content_type); self.send_header("Content-Length",str(len(data))); self.send_header("X-Content-Type-Options","nosniff");
        for k,v in (headers or {}).items(): self.send_header(k,v)
        self.end_headers(); self.wfile.write(data)
    def send_json(self,payload,status=200): self.send_bytes(json.dumps(payload,ensure_ascii=False).encode(),"application/json; charset=utf-8",status)
    def redirect(self,location,headers=None): self.send_response(302); self.send_header("Location",location); [self.send_header(k,v) for k,v in (headers or {}).items()]; self.end_headers()
    def read_body(self):
        length=int(self.headers.get("Content-Length","0") or 0)
        if length>18*1024*1024: raise ValueError("Request is too large")
        return self.rfile.read(length)
    def read_json(self):
        raw=self.read_body(); return json.loads(raw.decode("utf-8")) if raw else {}
    def token(self):
        jar=cookies.SimpleCookie(self.headers.get("Cookie","")); return jar.get("sarah_session").value if jar.get("sarah_session") else ""
    def authenticated(self):
        token=self.token(); expiry=SESSIONS.get(token,0)
        if expiry>time.time(): SESSIONS[token]=time.time()+SESSION_TTL; return True
        if token: SESSIONS.pop(token,None)
        return False
    def require_api(self):
        if not self.authenticated(): self.send_json({"ok":False,"error":"login_required"},401); return False
        return True
    def path_parts(self): return urllib.parse.urlparse(self.path).path
    def do_GET(self):
        init_db(); path=self.path_parts()
        if path=="/login": return self.login_page()
        if path=="/logout":
            SESSIONS.pop(self.token(),None); return self.redirect("/login",{"Set-Cookie":"sarah_session=; Path=/; Max-Age=0; HttpOnly; SameSite=Lax"})
        if path=="/":
            if not self.authenticated(): return self.redirect("/login")
            html=(CONFIG.root/"templates/index_full.html").read_text(encoding="utf-8").replace("__PROVIDER__",CONFIG.provider)
            return self.send_bytes(html.encode(),"text/html; charset=utf-8")
        if path.startswith("/static/"): return self.serve(CONFIG.root/"static"/Path(path).name)
        if path=="/manifest.webmanifest": return self.serve(CONFIG.root/"static/manifest.json","application/manifest+json")
        if path=="/sw.js": return self.serve(CONFIG.root/"static/sw.js","application/javascript")
        if path.startswith("/photos/"):
            if not self.authenticated(): return self.redirect("/login")
            return self.serve(CONFIG.photo_dir/Path(path).name,"image/jpeg")
        if path.startswith("/exports/"):
            if not self.authenticated(): return self.redirect("/login")
            return self.serve(CONFIG.export_dir/Path(path).name,"application/zip",attachment=True)
        if path.startswith("/api/"):
            if not self.require_api(): return
            return self.api_get(path)
        self.send_json({"ok":False,"error":"not_found"},404)
    def do_POST(self):
        init_db(); path=self.path_parts()
        if path=="/login": return self.login_post()
        if path.startswith("/api/"):
            if not self.require_api(): return
            return self.api_post(path)
        self.send_json({"ok":False,"error":"not_found"},404)
    def serve(self,path:Path,content_type=None,attachment=False):
        try:
            safe=path.resolve(); allowed=[CONFIG.root.resolve(),CONFIG.photo_dir.resolve(),CONFIG.export_dir.resolve()]
            if not any(base==safe or base in safe.parents for base in allowed) or not safe.is_file(): raise FileNotFoundError
            ctype=content_type or mimetypes.guess_type(safe.name)[0] or "application/octet-stream"; headers={}
            if attachment: headers["Content-Disposition"]=f'attachment; filename="{safe.name}"'
            self.send_bytes(safe.read_bytes(),ctype,200,headers)
        except FileNotFoundError:self.send_json({"ok":False,"error":"not_found"},404)
    def login_page(self,error=""):
        html=(CONFIG.root/"templates/login_full.html").read_text(encoding="utf-8").replace("{error}",f'<p class="error">{error}</p>' if error else '')
        self.send_bytes(html.encode(),"text/html; charset=utf-8")
    def login_post(self):
        form=urllib.parse.parse_qs(self.read_body().decode("utf-8")); pin=form.get("pin",[""])[0]
        if CONFIG.pin_hash and verify_pin(CONFIG.pin_hash,pin):
            token=secrets.token_urlsafe(32); SESSIONS[token]=time.time()+SESSION_TTL
            return self.redirect("/",{"Set-Cookie":f"sarah_session={token}; Path=/; Max-Age={SESSION_TTL}; HttpOnly; SameSite=Lax"})
        self.login_page("That PIN was not accepted.")
    def api_get(self,path):
        if path=="/api/status":
            p=get_provider(); model=CONFIG.openai_model if CONFIG.provider=="openai" else CONFIG.bedrock_model_id if CONFIG.provider=="bedrock" else CONFIG.ollama_model if CONFIG.provider=="ollama" else "built-in-demo"
            return self.send_json({"ok":True,"provider":CONFIG.provider,"model":model,"live_web_available":bool(getattr(p,"supports_live_web",False) and CONFIG.openai_web_search),"vision_available":bool(getattr(p,"supports_vision",False))})
        if path=="/api/messages": return self.send_json({"ok":True,"messages":rows("SELECT * FROM conversation_messages ORDER BY id DESC LIMIT 100")[::-1]})
        if path=="/api/memories": return self.send_json({"ok":True,"memories":list_memories(200)})
        if path=="/api/preferences": return self.send_json({"ok":True,"preferences":rows("SELECT * FROM preferences ORDER BY category,key")})
        if path=="/api/trips":
            trips=rows("SELECT * FROM trips ORDER BY id DESC")
            for t in trips:t["facts"]=rows("SELECT * FROM trip_facts WHERE trip_id=? ORDER BY id",(t["id"],))
            return self.send_json({"ok":True,"trips":trips})
        if path=="/api/photos": return self.send_json({"ok":True,"photos":rows("SELECT p.*,t.name AS trip_name FROM photos p LEFT JOIN trips t ON t.id=p.trip_id ORDER BY p.id DESC")})
        if path=="/api/deals": return self.send_json({"ok":True,"deals":rows("SELECT * FROM deal_watches ORDER BY id DESC")})
        self.send_json({"ok":False,"error":"not_found"},404)
    def api_post(self,path):
        try: payload=self.read_json()
        except Exception as exc:return self.send_json({"ok":False,"error":str(exc)},400)
        try:
            if path=="/api/chat": return self.chat(payload)
            if path in {"/api/remember","/api/memories"}:
                mid=save_memory(str(payload.get("title") or "Shared memory"),str(payload.get("summary") or ""),str(payload.get("detail") or ""),list(payload.get("tags") or []),int(payload.get("importance") or 5),str(payload.get("source_type") or "explicit_user_save"),str(payload.get("source_id") or "") or None); return self.send_json({"ok":True,"id":mid})
            if path=="/api/trips": return self.add_trip(payload)
            if path.startswith("/api/trips/") and path.endswith("/facts"): return self.add_fact(int(path.split('/')[3]),payload)
            if path=="/api/preferences": return self.preference(payload)
            if path=="/api/photos": return self.photo(payload)
            if path.startswith("/api/photos/") and path.endswith("/analyze"): return self.analyze_photo(int(path.split('/')[3]))
            if path=="/api/deals": return self.add_deal(payload)
            if path.startswith("/api/deals/") and path.endswith("/check"): return self.check_deal(int(path.split('/')[3]))
            if path=="/api/explore": return self.explore(payload)
            if path=="/api/export":
                out=export_local_data(); return self.send_json({"ok":True,"filename":out.name,"download_url":f"/exports/{urllib.parse.quote(out.name)}"})
            return self.send_json({"ok":False,"error":"not_found"},404)
        except ValueError as exc:return self.send_json({"ok":False,"error":str(exc)},400)
        except Exception as exc:return self.send_json({"ok":False,"error":f"{type(exc).__name__}: {exc}"},500)
    def chat(self,payload):
        text=str(payload.get("message") or "").strip(); mode=str(payload.get("mode") or "chat")
        if not text: raise ValueError("Please type a message.")
        if len(text)>8000: raise ValueError("That message is too long for this prototype.")
        want_web=mode in {"research","deals"}; provider=get_provider(); use_web=bool(want_web and getattr(provider,"supports_live_web",False) and CONFIG.openai_web_search)
        history=get_history(); execute("INSERT INTO conversation_messages(role,content,mode,created_at) VALUES(?,?,?,?)",("user",text,mode,now_iso()))
        try: result=provider.chat(system_prompt(context_for(text,use_web,False)),history,text,web_search=want_web)
        except Exception as exc:
            error=str(exc) if isinstance(exc,ProviderError) else f"Provider error: {type(exc).__name__}: {exc}"; return self.send_json({"ok":False,"error":error},502)
        execute("INSERT INTO conversation_messages(role,content,mode,created_at) VALUES(?,?,?,?)",("assistant",result.text,mode,now_iso())); log_event("chat_turn",{"provider":result.provider,"model":result.model,"mode":mode,"live_web_used":result.live_web_used})
        links=attraction_links(str(payload.get("destination") or text)) if want_web and not result.live_web_used and mode=="research" else []
        self.send_json({"ok":True,"reply":result.text,"provider":result.provider,"model":result.model,"live_web_used":result.live_web_used,"warning":result.warning,"links":links})
    def add_trip(self,p):
        name=str(p.get("name") or "").strip(); dest=str(p.get("destination") or "").strip()
        if not name or not dest: raise ValueError("Trip name and destination are required.")
        s=now_iso(); tid=execute("INSERT INTO trips(name,destination,start_date,end_date,status,notes,worries,favorite_moments,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)",(name[:200],dest[:300],str(p.get("start_date") or "")[:20],str(p.get("end_date") or "")[:20],str(p.get("status") or "wishlist")[:30],str(p.get("notes") or "")[:10000],str(p.get("worries") or "")[:5000],str(p.get("favorite_moments") or "")[:10000],s,s)); self.send_json({"ok":True,"id":tid})
    def add_fact(self,tid,p):
        if not row("SELECT id FROM trips WHERE id=?",(tid,)):return self.send_json({"ok":False,"error":"Trip not found"},404)
        label=str(p.get("label") or "").strip(); value=str(p.get("value") or "").strip()
        if not label or not value:raise ValueError("Fact label and value are required.")
        fid=execute("INSERT INTO trip_facts(trip_id,fact_type,label,value,source,verified,created_at) VALUES(?,?,?,?,?,?,?)",(tid,str(p.get("fact_type") or "other")[:50],label[:200],value[:3000],str(p.get("source") or "user_confirmed")[:200],1,now_iso())); self.send_json({"ok":True,"id":fid})
    def preference(self,p):
        cat=str(p.get("category") or "general").strip()[:100]; key=str(p.get("key") or "").strip()[:100]; value=str(p.get("value") or "").strip()[:3000]
        if not key or not value:raise ValueError("Preference name and value are required.")
        s=now_iso()
        with connect() as conn:conn.execute("INSERT INTO preferences(category,key,value,created_at,updated_at) VALUES(?,?,?,?,?) ON CONFLICT(category,key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at",(cat,key,value,s,s))
        self.send_json({"ok":True})
    def photo(self,p):
        filename,original,_=sanitize_base64(str(p.get("filename") or "trip_photo.jpg"),str(p.get("data_url") or "")); trip=p.get("trip_id") or None
        pid=execute("INSERT OR IGNORE INTO photos(trip_id,filename,original_name,caption,created_at) VALUES(?,?,?,?,?)",(int(trip) if trip else None,filename,original,str(p.get("caption") or "")[:2000],now_iso()))
        if pid==0:
            existing=row("SELECT id FROM photos WHERE filename=?",(filename,)); pid=int(existing["id"]) if existing else 0
        self.send_json({"ok":True,"id":pid,"filename":filename,"note":"A sanitized copy was stored; EXIF/GPS metadata was stripped."})
    def analyze_photo(self,pid):
        photo=row("SELECT p.*,t.destination,t.name AS trip_name FROM photos p LEFT JOIN trips t ON t.id=p.trip_id WHERE p.id=?",(pid,))
        if not photo:return self.send_json({"ok":False,"error":"Photo not found"},404)
        provider=get_provider(); prompt=("Please look at this trip photo and talk to me naturally about what catches your attention. Comment on composition and mood, then suggest one or two respectful ideas for another photo location, angle, lighting condition, or nearby type of setting. Do not identify unknown people. Do not invent the location. "f"User caption: {photo.get('caption') or 'none'}. Trip destination: {photo.get('destination') or 'not supplied'}.")
        try:result=provider.chat(system_prompt(context_for(prompt,False,bool(getattr(provider,'supports_vision',False)))),get_history(),prompt,image=read_photo_bytes(photo["filename"]))
        except Exception as exc:return self.send_json({"ok":False,"error":str(exc)},502)
        execute("UPDATE photos SET analysis=?,vision_provider=? WHERE id=?",(result.text,result.provider,pid)); self.send_json({"ok":True,"analysis":result.text,"provider":result.provider,"vision_used":result.vision_used,"warning":result.warning})
    def add_deal(self,p):
        origin=str(p.get("origin") or "").strip(); dest=str(p.get("destination") or "").strip()
        if not origin or not dest:raise ValueError("Origin and destination are required.")
        did=execute("INSERT INTO deal_watches(origin,destination,depart_date,return_date,travelers,max_price,notes,created_at) VALUES(?,?,?,?,?,?,?,?)",(origin[:200],dest[:200],str(p.get("depart_date") or "")[:20],str(p.get("return_date") or "")[:20],max(1,int(p.get("travelers") or 1)),float(p["max_price"]) if p.get("max_price") else None,str(p.get("notes") or "")[:3000],now_iso())); self.send_json({"ok":True,"id":did})
    def check_deal(self,did):
        d=row("SELECT * FROM deal_watches WHERE id=?",(did,))
        if not d:return self.send_json({"ok":False,"error":"Deal watch not found"},404)
        links=flight_deal_links(d["origin"],d["destination"],d.get("depart_date") or "",d.get("return_date") or ""); provider=get_provider(); use_web=bool(getattr(provider,"supports_live_web",False) and CONFIG.openai_web_search); text=""; warning=""
        if use_web:
            prompt=f"Search for currently advertised flight options from {d['origin']} to {d['destination']} for {d.get('depart_date') or 'flexible dates'} through {d.get('return_date') or 'flexible return'}. Travelers: {d.get('travelers') or 1}. Target total price: {d.get('max_price') or 'not set'}. State search time, compare total cost, include sources, and never guarantee availability. Notes: {d.get('notes') or 'none'}."
            try:r=provider.chat(system_prompt(context_for(prompt,True,False)),get_history(),prompt,web_search=True); text=r.text; warning=r.warning
            except Exception as exc:warning=str(exc)
        if not text:text="I did not run a live fare search. I made safe comparison links instead. Check baggage, seat fees, taxes, airport transfers, cancellation rules, and the airline’s own website before buying."
        execute("UPDATE deal_watches SET last_checked=?,last_result=? WHERE id=?",(now_iso(),text[:15000],did)); self.send_json({"ok":True,"result":text,"links":links,"live_web_used":bool(use_web and text),"warning":warning})
    def explore(self,p):
        dest=str(p.get("destination") or "").strip(); interests=str(p.get("interests") or "").strip()
        if not dest:raise ValueError("Enter a destination.")
        links=attraction_links(dest,interests)+lodging_links(dest); provider=get_provider(); use_web=bool(getattr(provider,"supports_live_web",False) and CONFIG.openai_web_search); prompt=f"Help me explore {dest}. Interests or needs: {interests or 'general first-time visitor ideas'}. Find major sights, quieter alternatives, an indoor backup, a low-cost option, and practical transit/pacing advice. Verify current details if live search is available; otherwise label them as needing verification."
        try:r=provider.chat(system_prompt(context_for(prompt,use_web,False)),get_history(),prompt,web_search=True); self.send_json({"ok":True,"reply":r.text,"links":links,"live_web_used":r.live_web_used,"warning":r.warning})
        except Exception as exc:self.send_json({"ok":True,"reply":"I could not reach the model, but I made safe research links below.","links":links,"live_web_used":False,"warning":str(exc)})

def main():
    parser=argparse.ArgumentParser();parser.add_argument("--open-browser",action="store_true");args=parser.parse_args();init_db(); laptop=f"http://127.0.0.1:{CONFIG.port}";phone=f"http://{local_ip()}:{CONFIG.port}";print("\nSarah Morgan Travel Companion");print(f"Laptop: {laptop}");print(f"Phone on the same Wi-Fi: {phone}");print("Do not port-forward this server to the public internet.\n")
    if args.open_browser:threading.Timer(1,lambda:webbrowser.open(laptop)).start()
    server=ThreadingHTTPServer((CONFIG.host,CONFIG.port),Handler)
    try:server.serve_forever()
    except KeyboardInterrupt:print("\nSarah stopped safely.")
    finally:server.server_close()
if __name__=="__main__":main()
