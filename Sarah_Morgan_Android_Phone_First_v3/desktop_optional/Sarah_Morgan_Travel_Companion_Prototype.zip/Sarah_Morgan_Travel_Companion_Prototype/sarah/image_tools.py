from __future__ import annotations
import base64, hashlib, io
from pathlib import Path
from .config import CONFIG

ALLOWED={"jpg","jpeg","png","webp"}

def sanitize_base64(filename: str, data_url: str) -> tuple[str,str,str]:
    extension=filename.rsplit('.',1)[-1].lower() if '.' in filename else ''
    if extension not in ALLOWED: raise ValueError("Use a JPG, PNG, or WEBP image")
    if ',' not in data_url: raise ValueError("The image data is incomplete")
    try: raw=base64.b64decode(data_url.split(',',1)[1],validate=True)
    except Exception as exc: raise ValueError("The image data could not be decoded") from exc
    if not raw or len(raw)>15*1024*1024: raise ValueError("The image is empty or larger than 15 MB")
    try:
        from PIL import Image, ImageOps
    except ImportError as exc:
        raise ValueError("Photo support is not installed. Run INSTALL_PHOTO_SUPPORT.bat once.") from exc
    try:
        image=Image.open(io.BytesIO(raw)); image.verify(); image=Image.open(io.BytesIO(raw)); image=ImageOps.exif_transpose(image).convert('RGB')
    except Exception as exc: raise ValueError("The uploaded file is not a readable image") from exc
    image.thumbnail((CONFIG.photo_max_pixels,CONFIG.photo_max_pixels),Image.Resampling.LANCZOS)
    digest=hashlib.sha256(raw).hexdigest()[:20]; saved=f"trip_photo_{digest}.jpg"; target=(CONFIG.photo_dir/saved).resolve(); target.relative_to(CONFIG.photo_dir.resolve())
    image.save(target,format='JPEG',quality=88,optimize=True)
    return saved,filename[:250],'image/jpeg'

def read_photo_bytes(filename: str):
    path=(CONFIG.photo_dir/Path(filename).name).resolve(); path.relative_to(CONFIG.photo_dir.resolve())
    if not path.is_file(): raise FileNotFoundError(filename)
    return path.read_bytes(),'jpeg'
