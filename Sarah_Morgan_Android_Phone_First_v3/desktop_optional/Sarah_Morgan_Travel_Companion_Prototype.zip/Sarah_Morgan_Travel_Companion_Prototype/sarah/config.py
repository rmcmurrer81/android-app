from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def load_env(path: Path) -> None:
    if not path.is_file():
        return
    for raw in path.read_text(encoding="utf-8-sig").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip())


load_env(ROOT / ".env")


def _int(name: str, default: int) -> int:
    try: return int(os.getenv(name, str(default)))
    except ValueError: return default


def _bool(name: str, default: bool = False) -> bool:
    return os.getenv(name, "1" if default else "0").strip().lower() in {"1", "true", "yes", "on"}


@dataclass(frozen=True)
class Config:
    root: Path = ROOT
    data_dir: Path = ROOT / "data"
    db_path: Path = ROOT / "data" / "sarah.db"
    photo_dir: Path = ROOT / "data" / "photos"
    export_dir: Path = ROOT / "data" / "exports"
    candidate_dir: Path = ROOT / "TemporaryAI" / "candidates" / "sarah_morgan_travel_companion_20260805"
    host: str = os.getenv("SARAH_HOST", "0.0.0.0")
    port: int = _int("SARAH_PORT", 8769)
    provider: str = os.getenv("SARAH_PROVIDER", "demo").strip().lower()
    secret_key: str = os.getenv("SARAH_SECRET_KEY", "development-only-change-me")
    pin_hash: str = os.getenv("SARAH_PIN_HASH", "")
    max_history: int = _int("SARAH_MAX_HISTORY", 12)
    max_memories: int = _int("SARAH_MAX_MEMORIES", 8)
    photo_max_pixels: int = _int("SARAH_PHOTO_MAX_PIXELS", 1600)
    openai_model: str = os.getenv("OPENAI_MODEL", "gpt-5-mini")
    openai_web_search: bool = _bool("OPENAI_ENABLE_WEB_SEARCH", False)
    aws_region: str = os.getenv("AWS_REGION", "us-east-1")
    bedrock_model_id: str = os.getenv("BEDROCK_MODEL_ID", "")
    ollama_url: str = os.getenv("OLLAMA_URL", "http://127.0.0.1:11434").rstrip("/")
    ollama_model: str = os.getenv("OLLAMA_MODEL", "llama3.1:8b")

CONFIG=Config()
for path in (CONFIG.data_dir, CONFIG.photo_dir, CONFIG.export_dir): path.mkdir(parents=True, exist_ok=True)
