from __future__ import annotations

import json
import sqlite3
import zipfile
from datetime import datetime, timezone
from pathlib import Path

from .config import CONFIG

TABLES = ["memories", "trips", "trip_facts", "preferences", "photos", "deal_watches", "conversation_messages"]


def export_local_data() -> Path:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    output = CONFIG.export_dir / f"sarah_local_backup_{stamp}.zip"
    with sqlite3.connect(CONFIG.db_path) as conn, zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as archive:
        conn.row_factory = sqlite3.Row
        payload = {table: [dict(row) for row in conn.execute(f"SELECT * FROM {table}").fetchall()] for table in TABLES}
        archive.writestr("sarah_data.json", json.dumps(payload, indent=2, ensure_ascii=False))
        archive.write(CONFIG.candidate_dir / "temporary_ai_profile.json", "candidate/temporary_ai_profile.json")
        archive.write(CONFIG.candidate_dir / "creation_request.json", "candidate/creation_request.json")
        for photo in CONFIG.photo_dir.glob("*.jpg"):
            archive.write(photo, f"photos/{photo.name}")
        archive.writestr("README.txt", "This backup intentionally excludes .env, API keys, PIN hash, and session secret.\n")
    return output
