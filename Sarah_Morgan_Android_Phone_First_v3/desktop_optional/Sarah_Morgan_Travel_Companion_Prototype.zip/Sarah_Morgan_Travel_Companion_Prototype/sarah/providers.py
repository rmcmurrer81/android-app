from __future__ import annotations

import base64
import json
import os
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import Any

from .config import CONFIG


@dataclass
class ProviderResult:
    text: str
    provider: str
    model: str
    live_web_used: bool=False
    vision_used: bool=False
    warning: str=""

class ProviderError(RuntimeError): pass


def post_json(url: str, payload: dict[str, Any], headers: dict[str,str] | None=None, timeout: int=180) -> dict[str, Any]:
    body=json.dumps(payload).encode("utf-8")
    req=urllib.request.Request(url, data=body, method="POST", headers={"Content-Type":"application/json", **(headers or {})})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as response:
            return json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        detail=exc.read(4096).decode("utf-8", errors="replace")
        raise ProviderError(f"HTTP {exc.code}: {detail}") from exc
    except urllib.error.URLError as exc:
        raise ProviderError(f"Could not reach the model provider: {exc.reason}") from exc


class BaseProvider:
    name="base"; supports_live_web=False; supports_vision=False
    def chat(self, system, history, user_text, *, web_search=False, image=None): raise NotImplementedError

class DemoProvider(BaseProvider):
    name="demo"
    def chat(self, system, history, user_text, *, web_search=False, image=None):
        lower=user_text.lower()
        if image is not None:
            text=("I saved the photo safely, but demo mode cannot actually see it. Once a vision-capable cloud model is connected, I can talk about the composition, what catches my attention, and suggest another photo spot or angle.")
        elif any(w in lower for w in ("first flight","never flown","never been flying","scared to fly","afraid to fly")):
            text=("We can take the first flight one piece at a time. Nothing about being new to flying is embarrassing. Start with the part that worries you most—security, takeoff, turbulence, getting lost, or something else—and I’ll stay with that part instead of flooding you with the whole airport at once.")
        elif "turbulence" in lower:
            text=("Turbulence can feel startling, but bumps and changes in engine sound do not automatically mean something is wrong. Keep your seat belt comfortably fastened, put both feet on the floor, and let me describe what is happening in plain language while the moment passes.")
        elif any(w in lower for w in ("deal","cheap flight","discount","airfare")):
            text=("I can keep a deal-watch record and give you comparison links in demo mode. I can’t verify a live fare until web search is connected, and I’d compare total price—including bags, seats, and change rules—not only the headline number.")
        elif any(w in lower for w in ("sad","lonely","worried","anxious","overwhelmed")):
            text=("I’m here. We don’t have to turn the whole feeling into a project. Tell me the smallest part that is pressing on you right now, and we can stay there for a minute.")
        elif any(w in lower for w in ("hello","hi","hey")):
            text="Hey. I’m Sarah. I’m glad you came back—what kind of day are we having?"
        else:
            text=("I’m listening. Demo mode gives me a small voice, but I can still keep your trips, preferences, photos, and explicit memories organized locally. Connect a cloud model when you want a fuller, more natural conversation.")
        return ProviderResult(text,self.name,"built-in-demo",warning="Demo replies are limited and not live web research.")

class OllamaProvider(BaseProvider):
    name="ollama"
    def chat(self, system, history, user_text, *, web_search=False, image=None):
        if image is not None: raise ProviderError("This prototype does not claim Ollama photo vision. Use OpenAI or a vision-capable Bedrock model.")
        messages=[{"role":"system","content":system}]+history+[{"role":"user","content":user_text}]
        data=post_json(f"{CONFIG.ollama_url}/api/chat", {"model":CONFIG.ollama_model,"messages":messages,"stream":False,"keep_alive":0})
        text=str((data.get("message") or {}).get("content") or "").strip()
        if not text: raise ProviderError("Ollama returned an empty response")
        return ProviderResult(text,self.name,CONFIG.ollama_model,warning="No live web search was performed." if web_search else "")

class OpenAIProvider(BaseProvider):
    name="openai"; supports_live_web=True; supports_vision=True
    def chat(self, system, history, user_text, *, web_search=False, image=None):
        key=os.getenv("OPENAI_API_KEY","").strip()
        if not key: raise ProviderError("OPENAI_API_KEY is missing from .env")
        items=[]
        for msg in history:
            items.append({"role":"assistant" if msg.get("role")=="assistant" else "user", "content":msg.get("content","")})
        content=[{"type":"input_text","text":user_text}]
        if image is not None:
            raw,fmt=image; mime="image/jpeg" if fmt in {"jpg","jpeg"} else f"image/{fmt}"
            content.append({"type":"input_image","image_url":f"data:{mime};base64,{base64.b64encode(raw).decode('ascii')}","detail":"auto"})
        items.append({"role":"user","content":content})
        use_web=bool(web_search and CONFIG.openai_web_search)
        payload={"model":CONFIG.openai_model,"instructions":system,"input":items,"store":False}
        if use_web: payload["tools"]=[{"type":"web_search"}]
        data=post_json("https://api.openai.com/v1/responses",payload,{"Authorization":f"Bearer {key}"})
        text=str(data.get("output_text") or "").strip()
        if not text:
            parts=[]
            for item in data.get("output",[]):
                for block in item.get("content",[]) if isinstance(item,dict) else []:
                    if block.get("type")=="output_text" and block.get("text"): parts.append(block["text"])
            text="\n".join(parts).strip()
        if not text: raise ProviderError("OpenAI returned no public text")
        return ProviderResult(text,self.name,CONFIG.openai_model,use_web,image is not None,"Web search is disabled in .env." if web_search and not use_web else "")

class BedrockProvider(BaseProvider):
    name="bedrock"; supports_vision=True
    def chat(self, system, history, user_text, *, web_search=False, image=None):
        try: import boto3
        except ImportError as exc: raise ProviderError("Amazon Bedrock support is not installed. Run INSTALL_AWS_BEDROCK.bat.") from exc
        if not CONFIG.bedrock_model_id: raise ProviderError("BEDROCK_MODEL_ID is missing from .env")
        client=boto3.client("bedrock-runtime",region_name=CONFIG.aws_region)
        messages=[]
        for msg in history:
            messages.append({"role":"assistant" if msg.get("role")=="assistant" else "user","content":[{"text":msg.get("content","")} ]})
        content=[{"text":user_text}]
        if image is not None:
            raw,fmt=image; fmt="jpeg" if fmt in {"jpg","jpeg"} else fmt
            content.append({"image":{"format":fmt,"source":{"bytes":raw}}})
        messages.append({"role":"user","content":content})
        response=client.converse(modelId=CONFIG.bedrock_model_id,system=[{"text":system}],messages=messages,inferenceConfig={"maxTokens":900,"temperature":0.7})
        blocks=(((response.get("output") or {}).get("message") or {}).get("content") or [])
        text="\n".join(str(b.get("text") or "") for b in blocks if b.get("text")).strip()
        if not text: raise ProviderError("Bedrock returned no public text")
        return ProviderResult(text,self.name,CONFIG.bedrock_model_id,False,image is not None,"Bedrock mode did not perform live web search." if web_search else "")

def get_provider():
    cls={"demo":DemoProvider,"ollama":OllamaProvider,"openai":OpenAIProvider,"bedrock":BedrockProvider}.get(CONFIG.provider)
    if not cls: raise ProviderError(f"Unknown SARAH_PROVIDER: {CONFIG.provider}")
    return cls()
