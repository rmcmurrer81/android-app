from __future__ import annotations

from urllib.parse import quote_plus


def attraction_links(destination: str, interests: str = "") -> list[dict[str, str]]:
    place = destination.strip()
    extra = interests.strip()
    base = f"things to do in {place}" + (f" {extra}" if extra else "")
    return [
        {"label": "Google travel search", "url": f"https://www.google.com/search?q={quote_plus(base)}"},
        {"label": "Google Maps", "url": f"https://www.google.com/maps/search/{quote_plus(base)}"},
        {"label": "Official tourism search", "url": f"https://www.google.com/search?q={quote_plus(place + ' official tourism things to do')}"},
        {"label": "Accessible travel search", "url": f"https://www.google.com/search?q={quote_plus(place + ' accessible attractions sensory quiet hours')}"},
    ]


def flight_deal_links(origin: str, destination: str, depart_date: str = "", return_date: str = "") -> list[dict[str, str]]:
    if depart_date and return_date:
        date_text = f"{depart_date} through {return_date}"
    elif depart_date:
        date_text = depart_date
    elif return_date:
        date_text = f"return by {return_date}"
    else:
        date_text = "flexible dates"
    query = f"flights from {origin} to {destination} {date_text} cheapest fare baggage fees".strip()
    return [
        {"label": "Google Flights search", "url": f"https://www.google.com/travel/flights?q={quote_plus(query)}"},
        {"label": "Kayak search", "url": f"https://www.google.com/search?q={quote_plus('site:kayak.com ' + query)}"},
        {"label": "Skyscanner search", "url": f"https://www.google.com/search?q={quote_plus('site:skyscanner.com ' + query)}"},
        {"label": "Airline-direct comparison", "url": f"https://www.google.com/search?q={quote_plus(query + ' airline official website')}"},
    ]


def lodging_links(destination: str, start_date: str = "", end_date: str = "") -> list[dict[str, str]]:
    query = f"hotels in {destination} {start_date} {end_date} total price resort fees cancellation".strip()
    return [
        {"label": "Google Hotels search", "url": f"https://www.google.com/travel/hotels?q={quote_plus(query)}"},
        {"label": "Official hotel-direct search", "url": f"https://www.google.com/search?q={quote_plus(query + ' official hotel')}"},
    ]
