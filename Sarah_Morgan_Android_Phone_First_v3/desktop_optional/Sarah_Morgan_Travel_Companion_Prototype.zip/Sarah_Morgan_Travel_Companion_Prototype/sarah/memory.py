from __future__ import annotations

import json
import re
from typing import Any

from .database import execute, now_iso, rows


def save_memory(title: str, summary: str, detail: str = "", tags: list[str] | None = None,
                importance: int = 5, source_type: str = "explicit_user_save", source_id: str | None = None) -> int:
    title = title.strip()[:200] or "Shared memory"
    summary = summary.strip()[:3000]
    if not summary:
        raise ValueError("A memory summary is required")
    return execute(
        """INSERT INTO memories(title,summary,detail,tags,importance,source_type,source_id,status,created_at)
           VALUES(?,?,?,?,?,?,?,?,?)""",
        (title, summary, detail.strip()[:10000], json.dumps(tags or []), max(1, min(10, int(importance))),
         source_type, source_id, "approved", now_iso()),
    )


def list_memories(limit: int = 100) -> list[dict[str, Any]]:
    data = rows("SELECT * FROM memories WHERE status='approved' ORDER BY importance DESC, id DESC LIMIT ?", (limit,))
    for item in data:
        try:
            item["tags"] = json.loads(item.get("tags") or "[]")
        except json.JSONDecodeError:
            item["tags"] = []
    return data


def relevant_memories(query: str, limit: int = 8) -> list[dict[str, Any]]:
    tokens = {t for t in re.findall(r"[a-z0-9]+", query.lower()) if len(t) > 2}
    memories = list_memories(limit=250)
    scored = []
    for memory in memories:
        hay = " ".join([
            memory.get("title", ""), memory.get("summary", ""), memory.get("detail", ""),
            " ".join(memory.get("tags", [])),
        ]).lower()
        overlap = sum(1 for token in tokens if token in hay)
        score = overlap * 4 + int(memory.get("importance") or 5)
        if overlap or not tokens:
            scored.append((score, memory))
    scored.sort(key=lambda pair: (pair[0], pair[1].get("id", 0)), reverse=True)
    return [memory for _, memory in scored[:limit]]
