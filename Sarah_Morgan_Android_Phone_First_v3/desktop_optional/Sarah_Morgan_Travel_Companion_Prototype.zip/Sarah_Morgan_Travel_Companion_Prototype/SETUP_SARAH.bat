@echo off
setlocal
cd /d "%~dp0"
py -3 setup_sarah.py 2>nul || python setup_sarah.py
if errorlevel 1 goto :fail
echo.
echo Setup complete. Next, double-click START_SARAH.bat
pause
exit /b 0
:fail
echo.
echo Setup failed. Keep this window open and copy the error if you need help.
pause
exit /b 1
