@echo off
setlocal
cd /d "%~dp0"
py -3 -m pip install -r requirements-aws.txt 2>nul || python -m pip install -r requirements-aws.txt
if errorlevel 1 (
  echo AWS Bedrock installation failed.
) else (
  echo AWS Bedrock provider installed. Configure AWS credentials, then edit .env.
)
pause
