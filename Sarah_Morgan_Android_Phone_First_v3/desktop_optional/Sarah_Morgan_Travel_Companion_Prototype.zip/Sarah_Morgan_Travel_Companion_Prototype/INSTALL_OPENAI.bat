@echo off
setlocal
cd /d "%~dp0"
echo OpenAI support is built into Sarah and needs no Python package.
echo.
echo Open .env in Notepad and set:
echo SARAH_PROVIDER=openai
echo OPENAI_API_KEY=your_private_key_here
echo OPENAI_MODEL=gpt-5-mini
echo OPENAI_ENABLE_WEB_SEARCH=1
notepad .env
