from __future__ import annotations

import os
import tempfile
import unittest
from pathlib import Path


class SarahSourceTests(unittest.TestCase):
    def test_candidate_profile_exists_and_separate(self):
        root = Path(__file__).resolve().parents[1]
        import json
        profile = json.loads((root / "TemporaryAI/candidates/sarah_morgan_travel_companion_20260805/temporary_ai_profile.json").read_text())
        self.assertEqual(profile["display_name"], "Sarah Morgan")
        self.assertTrue(profile["privacy"]["kira_lisa_memory_excluded"])
        self.assertTrue(profile["truth_boundaries"]["never_overwrite_confirmed_trip_facts_from_chat"])

    def test_env_example_has_no_real_secret(self):
        root = Path(__file__).resolve().parents[1]
        text = (root / ".env.example").read_text()
        self.assertIn("OPENAI_API_KEY=", text)
        self.assertNotIn("sk-", text)
        self.assertNotIn("AKIA", text)

    def test_search_links_are_https(self):
        from sarah.travel_tools import attraction_links, flight_deal_links
        links = attraction_links("Boston") + flight_deal_links("EWR", "BOS")
        self.assertTrue(links)
        self.assertTrue(all(item["url"].startswith("https://") for item in links))

    def test_prompt_preserves_truth_boundary(self):
        from sarah.prompting import system_prompt
        prompt = system_prompt({"memories": [], "trips": [], "preferences": [], "facts": [], "live_search": False, "vision": False})
        self.assertIn("never overwrite", prompt.lower())
        self.assertIn("never claim you booked", prompt.lower())
        self.assertIn("Sarah Morgan", prompt)


if __name__ == "__main__":
    unittest.main()

class SecurityAndProviderTests(unittest.TestCase):
    def test_pin_hash_round_trip(self):
        from setup_sarah import hash_pin
        from sarah.security import verify_pin
        stored = hash_pin("2468")
        self.assertTrue(verify_pin(stored, "2468"))
        self.assertFalse(verify_pin(stored, "2469"))

    def test_demo_provider_first_flight(self):
        from sarah.providers import DemoProvider
        result = DemoProvider().chat("system", [], "I have never flown before")
        self.assertIn("first flight", result.text.lower())
        self.assertFalse(result.live_web_used)

    def test_openai_payload_uses_store_false_and_optional_tools(self):
        import os
        from unittest.mock import patch
        import sarah.providers as providers
        from sarah.config import CONFIG
        captured = {}
        def fake_post(url, payload, headers=None, timeout=180):
            captured.update(url=url, payload=payload, headers=headers)
            return {"output_text": "Hello from Sarah"}
        old = os.environ.get("OPENAI_API_KEY")
        os.environ["OPENAI_API_KEY"] = "test-key"
        try:
            with patch.object(providers, "post_json", side_effect=fake_post):
                # CONFIG.openai_web_search is frozen from import, so use chat without web here.
                result = providers.OpenAIProvider().chat("Sarah system", [], "hello")
            self.assertEqual(result.text, "Hello from Sarah")
            self.assertEqual(captured["url"], "https://api.openai.com/v1/responses")
            self.assertIs(captured["payload"]["store"], False)
            self.assertEqual(captured["payload"]["instructions"], "Sarah system")
            self.assertIn("Authorization", captured["headers"])
        finally:
            if old is None:
                os.environ.pop("OPENAI_API_KEY", None)
            else:
                os.environ["OPENAI_API_KEY"] = old
