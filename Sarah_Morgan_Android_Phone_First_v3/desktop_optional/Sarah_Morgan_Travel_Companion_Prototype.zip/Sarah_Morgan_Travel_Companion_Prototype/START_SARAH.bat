@echo off
setlocal
cd /d "%~dp0"
if not exist ".env" (
  call SETUP_SARAH.bat
  if errorlevel 1 exit /b 1
)
py -3 app.py --open-browser 2>nul || python app.py --open-browser
pause
