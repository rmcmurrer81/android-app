# Sarah Morgan Travel Companion — Phone + Laptop Prototype

Sarah is an **original adult synthetic person** created as a separate companion. She is not Kira, Lisa, or a copy of either person. This prototype preserves several Kira World design ideas:

- public conversation logs are not automatically trusted memory;
- trip facts are stored separately from conversational wording;
- Sarah can talk about ordinary life, feelings, books, movies, ideas, or anything else—not only travel;
- personal memories are saved only when you explicitly press **Remember this** or enter them in the Memory Book;
- Sarah never claims a booking, current price, reservation, or photo observation unless the relevant tool actually supplied it.

## What works in this prototype

- Responsive browser interface for a Windows laptop and a phone on the same Wi-Fi network.
- General conversation with Sarah.
- Trip planning, destination wish list, completed-trip history, preferences, worries, and favorite moments.
- First-flight and travel-anxiety calm support.
- Local, explicit Memory Book.
- Photo upload with EXIF/location metadata stripped before storage.
- Photo discussion and suggested places/angles for another picture when a vision-capable cloud model is connected.
- Attraction research and travel-deal searches when OpenAI web search is enabled.
- Manual deal-watch records and safe search links when live web search is unavailable.
- Replaceable model providers: Demo, Ollama, OpenAI Responses API, or Amazon Bedrock Converse.

## Honest limits

- Sarah does **not** book flights, hotels, or activities.
- Airline prices and availability change quickly. Sarah must label live-search time and tell you to verify before buying.
- Deal watches are manual in this first build. They do not spend API credits in the background.
- The phone version is a responsive web app. It is not yet a Play Store or App Store application.
- Phone access is intended for the same trusted Wi-Fi network. Do not expose port 8769 to the public internet.
- PWA installation normally needs HTTPS on a phone. The page still works normally in the phone browser over local Wi-Fi.

## Fastest start: Demo mode

1. Double-click `SETUP_SARAH.bat` once.
2. Choose a private PIN when asked.
3. Double-click `START_SARAH.bat`.
4. The laptop browser opens automatically.
5. The terminal shows a **phone address**, usually similar to `http://192.168.1.25:8769`.
6. On your phone, join the same Wi-Fi and enter that address.
7. Log in with the PIN you chose.

Demo mode works without API credits. Its replies are intentionally limited. Trip, memory, and deal-watch storage work immediately; run `INSTALL_PHOTO_SUPPORT.bat` once before saving photos.

## Connect OpenAI later

1. Double-click `INSTALL_OPENAI.bat` (it opens `.env`; no Python package is needed).
2. Edit the provider values in Notepad.
3. Set:

```text
SARAH_PROVIDER=openai
OPENAI_API_KEY=your_private_key_here
OPENAI_MODEL=gpt-5-mini
OPENAI_ENABLE_WEB_SEARCH=1
```

The key remains in the local `.env` file. Do not put `.env` in GitHub or send it to anyone.

OpenAI image analysis and web search require a compatible model and API account. The app sends `store=False` for Responses API requests.

## Photo support

Double-click `INSTALL_PHOTO_SUPPORT.bat` once before uploading photos. Base chat, trips, memories, and deal links work without it.

## Connect Amazon Bedrock later

1. Double-click `INSTALL_AWS_BEDROCK.bat`.
2. Configure AWS credentials through the normal AWS SDK credential chain.
3. Open `.env` and set:

```text
SARAH_PROVIDER=bedrock
AWS_REGION=us-east-1
BEDROCK_MODEL_ID=your_enabled_model_or_inference_profile_id
```

Choose a Bedrock model that supports the features you need. Photo analysis requires a vision-capable model.

## Connect Ollama

Set these values in `.env`:

```text
SARAH_PROVIDER=ollama
OLLAMA_URL=http://127.0.0.1:11434
OLLAMA_MODEL=llama3.1:8b
```

Ollama mode provides chat but this prototype does not claim local photo understanding.

## Important folders

```text
Sarah_Morgan_Travel_Companion_Prototype/
├── app.py
├── START_SARAH.bat
├── SETUP_SARAH.bat
├── .env                 # created locally; never share
├── data/
│   ├── sarah.db         # local conversations, trips, memories, preferences
│   ├── photos/          # sanitized photo copies
│   └── exports/         # user-requested backups
└── TemporaryAI/candidates/sarah_morgan_travel_companion_20260805/
```

## Backup

Open **Settings → Export local data**. The export excludes API keys and the `.env` file. Copy the exported ZIP to a safe drive.

## Run tests

Double-click `RUN_TESTS.bat`.

## Stop Sarah

Return to the black terminal window and press `Ctrl+C`. Closing only the browser does not stop the local server.

## Firewall note

Windows may ask whether Python can communicate through the firewall. For same-Wi-Fi phone use, allow it on **Private networks only**, not Public networks.
