@echo off
setlocal
cd /d "%~dp0"
py -3 -m pip install -r requirements-photo.txt 2>nul || python -m pip install -r requirements-photo.txt
if errorlevel 1 (
  echo Photo support installation failed.
) else (
  echo Photo support installed. Sarah will strip EXIF and GPS metadata from saved copies.
)
pause
