Sarah's runtime system prompt is assembled by `sarah/prompting.py` from this profile, explicit memories, trip records, preferences, and confirmed trip facts.
