# Kira World Compatibility Notes

This prototype was adapted from the architecture patterns supplied by Robert, not from Kira's or Lisa's identities.

Preserved ideas:

1. **Conversation log is not trusted memory.** The `conversation_messages` table is separate from the approved `memories` table.
2. **Public response and factual runtime truth are separate.** Sarah's conversational wording never directly changes `trip_facts`.
3. **Action wording is not completion proof.** Sarah cannot claim she booked, paid, called, or reserved anything.
4. **Person identity is separate from the model provider.** Demo, Ollama, OpenAI, and Bedrock can be swapped without replacing Sarah's candidate profile or local memories.
5. **Kira and Lisa remain separate.** Their supplied memory files were used only to understand schema and separation; their actual memory content was not copied into Sarah's package.
6. **Phone-first scope is bounded.** The first version is a local responsive web application rather than a full Kira World person activation or body.

The original `candidate_movement_intents.py` is not required because Sarah has no 3D body in this version. Travel actions are factual records and search suggestions, not body movement.
