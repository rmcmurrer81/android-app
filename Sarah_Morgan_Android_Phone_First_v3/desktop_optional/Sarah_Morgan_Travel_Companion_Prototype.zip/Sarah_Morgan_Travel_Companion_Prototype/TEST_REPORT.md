# Sarah Morgan Prototype Test Report

Build date: 2026-08-05

## Automated tests

- Python compilation: PASS
- Candidate identity separation: PASS
- No real credentials in `.env.example`: PASS
- HTTPS research/deal links: PASS
- Trip/factual truth prompt boundary: PASS
- PBKDF2 PIN hashing and verification: PASS
- Demo first-flight response route: PASS
- OpenAI Responses request uses `store=false`: PASS

Automated unit total: **7 passed**.

## End-to-end local integration test

A live local server was started on a test port and exercised through HTTP with a real session cookie.

Passed:

- PIN login
- provider/status read
- trip creation
- confirmed trip-fact creation
- preference creation
- demo chat turn
- explicit Memory Book save
- sanitized JPEG upload with EXIF removed
- honest demo photo-analysis fallback
- deal-watch creation and safe comparison links
- destination-exploration links
- local backup ZIP export

## Not live-tested in this build environment

- A real OpenAI API call
- A real Amazon Bedrock call
- A real Ollama call
- Phone access across Robert's home Wi-Fi
- Windows Defender Firewall prompt behavior
- PWA installation over HTTPS

These require Robert's own provider credentials, model access, Windows network, or phone.
