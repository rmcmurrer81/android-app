from __future__ import annotations

import getpass
import hashlib
import hmac
import secrets
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ENV_PATH = ROOT / ".env"
EXAMPLE = ROOT / ".env.example"


def hash_pin(pin: str) -> str:
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", pin.encode("utf-8"), salt, 310_000)
    return f"pbkdf2_sha256$310000${salt.hex()}${digest.hex()}"


def main() -> int:
    print("\nSarah Morgan Travel Companion setup\n")
    if ENV_PATH.exists():
        answer = input("A .env file already exists. Replace the PIN/secret? [y/N]: ").strip().lower()
        if answer not in {"y", "yes"}:
            print("Keeping the existing configuration.")
            return 0
    while True:
        pin = getpass.getpass("Choose a private phone/laptop PIN (at least 4 characters): ").strip()
        if len(pin) < 4:
            print("Please use at least 4 characters.")
            continue
        confirm = getpass.getpass("Enter the PIN again: ").strip()
        if pin != confirm:
            print("The PINs did not match.")
            continue
        break
    values = {}
    for line in EXAMPLE.read_text(encoding="utf-8").splitlines():
        if line.strip() and not line.lstrip().startswith("#") and "=" in line:
            key, value = line.split("=", 1)
            values[key] = value
    values["SARAH_PIN_HASH"] = hash_pin(pin)
    values["SARAH_SECRET_KEY"] = secrets.token_urlsafe(48)
    out = ["# Sarah local configuration. Never upload or share this file."]
    out.extend(f"{key}={value}" for key, value in values.items())
    ENV_PATH.write_text("\n".join(out) + "\n", encoding="utf-8")
    print("\nCreated .env with a PBKDF2-hashed PIN and random session secret.")
    print("Sarah starts in demo mode; no cloud API key is required.")
    print("Run INSTALL_PHOTO_SUPPORT.bat before sharing photos.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
